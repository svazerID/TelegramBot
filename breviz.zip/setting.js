// setting.js
module.exports = {
  BOT_TOKEN: "7732358172:AAHsqG_TCTmkHt8_5JpqOSwTMBRzxF14CjU", // Ganti dengan token bot
  MAX_RESULTS: 5, // jumlah hasil ytsearch
};
