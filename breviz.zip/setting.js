// setting.js
module.exports = {
  BOT_TOKEN: "", // Ganti dengan token bot
  MAX_RESULTS: 5, // jumlah hasil ytsearch
};
